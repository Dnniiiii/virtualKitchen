<!DOCTYPE html>
<html><head><title>Virtual Kitchen</title><link rel='stylesheet' href='css/style.css'></head><body>